"""Small green-search revision; all decisions retain hard CPU/BW/QoS checks.

Joint hop/delay bounds tighten optimistic first-hop domains. They certify only
necessary local conditions. Fail-first ordering and power-aware equal-hop
preferences remain heuristics; they do not guarantee global VNE optimality.
"""
import math

import numpy as np

from .efficient import EfficientAdaptiveVNE
from .models import EPS, canonical_edge
from .pruning import first_hop_packing_possible


class GreenAdaptiveVNE(EfficientAdaptiveVNE):
    name = 'ProposedAdaptive'

    def __init__(self, substrate, rng=None, *, joint_qos_checks=True,
                 domain_ordering=True, green_two_hop=True,
                 greedy_first=True, **kwargs):
        super().__init__(substrate, rng, **kwargs)
        self.joint_qos_checks = bool(joint_qos_checks)
        self.domain_ordering = bool(domain_ordering)
        self.green_two_hop = bool(green_two_hop)
        self.greedy_first = bool(greedy_first)
        self.qos_bound_layers = self.qos_bound_transitions = 0
        self._green_bw = None
        # Directed arcs already follow sorted host/port order. These indices
        # remove repeated neighbor sorting and physical-edge lookups.
        degree = np.bincount(self._arc_u, minlength=len(self._nodes))
        self._port_arcs = np.split(np.arange(len(self._arcs)), np.cumsum(degree)[:-1])

    def embed(self, vnr):
        self._green_bw = self._edge_residual({'bw': self.sn.bandwidth_residual})
        try:
            return super().embed(vnr)
        finally:
            self._green_bw = None
            self._request_profiles.clear()

    def _green_cache(self):
        # Standalone diagnostic calls receive fresh caches. During embedding,
        # all pruning uses the fixed request-start BW: tentative routes may
        # later be repaired and must never shrink these optimistic domains.
        return self._request_profiles if self._green_bw is not None else {}

    def _joint_delay_layers(self, target, bandwidth, hops, state, cache):
        key = ('green_delay_layers', target, bandwidth, hops)
        if key in cache:
            return cache[key]
        graph_key = ('green_arcs', bandwidth)
        arcs = cache.get(graph_key)
        if arcs is None:
            residual = self._edge_residual(state) if self._green_bw is None else self._green_bw
            allowed = residual[self._arc_edge] + EPS >= bandwidth
            arcs = self._arc_u[allowed], self._arc_v[allowed], self._arc_delay[allowed]
            cache[graph_key] = arcs
        source, destination, delay = arcs
        distance = np.full(len(self._nodes), np.inf)
        distance[self._index[target]] = 0.
        layers = [distance]
        # At-most-h-hop minimum delay. This computes joint QoS feasibility,
        # unlike independently minimizing hops and delay on different paths.
        for _ in range(min(hops, len(self._nodes) - 1)):
            following = distance.copy()
            np.minimum.at(following, source, distance[destination] + delay)
            self.qos_bound_layers += 1
            self.qos_bound_transitions += len(source)
            layers.append(following)
            if np.array_equal(following, distance):
                break
            distance = following
        self.qos_bound_builds += 1
        cache[key] = layers
        return layers

    def _port_domain(self, vnr, bandwidth, target, state, cache):
        key = ('green_ports', bandwidth, target, vnr.max_hops, vnr.max_delay)
        if key in cache:
            return cache[key]
        residual = self._edge_residual(state) if self._green_bw is None else self._green_bw
        eligible = ((residual[self._arc_edge] + EPS >= bandwidth)
                    & (self._arc_delay <= vnr.max_delay + EPS))
        if vnr.max_hops < 1:
            eligible[:] = False
        elif target is not None:
            if self.joint_qos_checks:
                layers = self._joint_delay_layers(target, bandwidth, vnr.max_hops, state, cache)
                remaining = layers[min(vnr.max_hops - 1, len(layers) - 1)]
                eligible &= self._arc_delay + remaining[self._arc_v] <= vnr.max_delay + EPS
            else:
                hops, delays = self._destination_bounds(target, bandwidth, state, cache)
                h = np.array([hops.get(n, math.inf) for n in self._nodes])
                d = np.array([delays.get(n, math.inf) for n in self._nodes])
                eligible &= 1 + h[self._arc_v] <= vnr.max_hops
                eligible &= self._arc_delay + d[self._arc_v] <= vnr.max_delay + EPS
        cache[key] = eligible
        return eligible

    def _first_hop_feasible(self, vnr, vnode, pnode, mapping, state):
        incident = [(edge, edge.v if edge.u == vnode else edge.u)
                    for edge in vnr.edges if vnode in (edge.u, edge.v) and edge.bandwidth > EPS]
        if len(incident) > self.packing_degree_limit:
            self.packing_bypasses += 1
            return True
        cache = self._green_cache()
        key = ('green_packing', vnode, pnode, tuple((other, mapping.get(other)) for _, other in incident))
        if key in cache:
            return cache[key]
        ports = self._port_arcs[self._index[pnode]]
        residual = self._edge_residual(state) if self._green_bw is None else self._green_bw
        capacities = residual[self._arc_edge[ports]].tolist()
        domains = [np.flatnonzero(self._port_domain(vnr, edge.bandwidth,
                        mapping.get(other), state, cache)[ports]).tolist()
                   for edge, other in incident]
        self.packing_checks += 1
        result = first_hop_packing_possible([edge.bandwidth for edge, _ in incident],
                                            capacities, domains, self.packing_degree_limit)
        self.packing_rejections += int(result is False)
        cache[key] = result is not False
        return cache[key]

    def _link_profile(self, vnr, edge, target, state):
        profile = super()._link_profile(vnr, edge, target, state)
        if not self.joint_qos_checks or target is None:
            return profile
        layers = self._joint_delay_layers(target, edge.bandwidth, vnr.max_hops,
                                          state, self._green_cache())
        feasible = layers[-1] <= vnr.max_delay + EPS
        # Each returned profile is request-local, so this does not alter any
        # other algorithm or persist after arrivals/releases change the state.
        return {node: profile[node] if feasible[i] else -math.inf
                for i, node in enumerate(self._nodes)}

    def _backtrack(self, vnr, order, index, mapping, state, paths):
        if self.greedy_first and index == 0 and not mapping:
            # One original-order construction, then fail-first recovery.
            # Both passes share counters, caches and the SAME total quota.
            candidates, ordering = self.candidate_limit, self.domain_ordering
            try:
                self.candidate_limit, self.domain_ordering = 1, False
                result = super()._backtrack(vnr, order, index, mapping, state, paths)
            finally:
                self.candidate_limit, self.domain_ordering = candidates, ordering
            if result is not None or self.last_search_budget_exhausted:
                return result
        if (self.domain_ordering and index < len(order)
                and self.last_search_nodes < self.search_budget):
            relaxed = self.sn.clone_state(state)
            relaxed['bw'] = dict(self.sn.bandwidth_residual)
            used = set(mapping.values())
            choices = []
            for vnode in order[index:]:
                context = self._score_context(vnr, vnode, mapping, relaxed)
                count = sum(node not in used and relaxed['cpu'][node] + EPS >= vnr.node_cpu[vnode]
                            and node in context['allowed']
                            and all(math.isfinite(profile[node]) for _, profile in context['incident'])
                            for node in self._nodes)
                incident = [edge for edge in vnr.edges if vnode in (edge.u, edge.v)]
                closed = sum((edge.v if edge.u == vnode else edge.u) in mapping for edge in incident)
                choices.append((count, -closed, -sum(e.bandwidth for e in incident),
                                -vnr.node_cpu[vnode], vnode))
            chosen = min(choices)[-1]
            order = order[:index] + [chosen] + [v for v in order[index:] if v != chosen]
        return super()._backtrack(vnr, order, index, mapping, state, paths)

    def _two_hop_context(self, state):
        return self.sn.powered_nodes(state) if self.green_two_hop else None

    def _two_hop_key(self, source, middle, target, bandwidth, delay, state, context):
        if not self.green_two_hop:
            return super()._two_hop_key(source, middle, target, bandwidth, delay, state, context)
        a, b = canonical_edge(source, middle), canonical_edge(middle, target)
        wake = 0. if middle in context else self.sn.p_idle + self.sn.boot_energy_joules / self.boot_amortization_seconds
        watts = wake + self.sn.p_link * sum(state['bw'][e] >= self.sn.bandwidth_capacity[e] - EPS
                                          for e in (a, b))
        return watts, delay, middle
